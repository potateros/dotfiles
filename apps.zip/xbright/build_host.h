#define BUILD_HOST "potatopc"
#define BRIGHTNESSFILE "/sys/class/backlight/intel_backlight/brightness"
#define MAXVALUE 976
#define VERSION "29.1dc8b70"
