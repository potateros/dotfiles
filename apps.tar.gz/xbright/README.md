XBright
=======
Extremely simple alternative to xbacklight made that uses new /sys/class/backlight/... (Linux 2.6+ ONLY)
Made even simplier and smaller

Usage:
------
```bash
# xbright [+-=[0-123]]
```

Installation:
-------------
make && sudo make install

Uninstallation:
---------------
sudo make uninstall

